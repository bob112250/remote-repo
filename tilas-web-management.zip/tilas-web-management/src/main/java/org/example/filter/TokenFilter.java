package org.example.filter;

/*
* 令牌校验的过滤器：验证登录信息，若没有登录返回错误信息（响应401状态码）
* */

import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.example.utils.CurrentHolder;
import org.example.utils.JwtUtils;

import java.io.IOException;

@Slf4j
@WebFilter(urlPatterns = "/*")  //指定拦截的请求的路径，/*表示拦截所有请求；/emp/* 表示拦截/emp下的所有请求    //注释掉是因为已经配置了拦截器interceptor
public class TokenFilter implements Filter {   //注意实现的Filter接口是servlet包下的

    /*服务器运行开始会执行的代码，只执行一次，一般用于配置环境，不需要可以不实现*/
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    /*捕获请求*/
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;   //请求的请求参数
        HttpServletResponse response = (HttpServletResponse) servletResponse;  //请求的响应参数

        //1.获取请求路径，如果路径中有/login，说明是登录请求，直接放行
        String requestURI = request.getRequestURI();  //获取的是uri地址
        if(requestURI.contains("/login")){
            log.info("登录请求，放行");
            filterChain.doFilter(request,response);   //放行（如果还有别的过滤器，会放行到下一个过滤器，即过滤器链；若是最后一个过滤器，会放行到资源处）
            return;   //放行后，会访问相应的资源（或者下一个过滤器），访问完资源后还会返回这个过滤器，执行剩下的代码，return即结束函数，让剩下的代码不要执行
        }

        //2.获取请求头中的token
        String token = request.getHeader("token");

        //3.若token为null，说明没登陆，返回错误信息
        if(token == null || token.isEmpty()){
            log.info("令牌为空，响应401");
            response.setStatus(401);  //设置响应状态码为401，未授权
            return;
        }

        //4.校验token是否有效，无效则返回错误信息
        try{
            Claims claims = JwtUtils.parseToken(token);   //解析令牌
            Integer employeeId = Integer.valueOf(claims.get("id").toString());   //从解析结果中获取员工id
            CurrentHolder.setCurrentId(employeeId);   //将id传给当前线程
            log.info("当前登录员工的id是：{}",employeeId);
        }catch (Exception e){   //如果令牌无效会解析操作会解析失败，并会抛出异常
            log.info("令牌无效，响应401");
            response.setStatus(401);
            return;
        }

        //5.放行
        filterChain.doFilter(request,response);

        //删除线程中的数据(注意一定要在放行之后删除数据，从过滤器放行后一层层访问到数据，之后会返回到过滤器执行剩下的代码)
        CurrentHolder.remove();
    }


    /*服务器运行结束会执行的代码，只执行一次，一般用于释放资源，不需要可以不实现*/
    @Override
    public void destroy() {

    }
}
