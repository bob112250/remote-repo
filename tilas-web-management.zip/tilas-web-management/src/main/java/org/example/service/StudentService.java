package org.example.service;

import org.example.pojo.PageResult;
import org.example.pojo.Student;
import org.example.pojo.StudentQueryParam;

import java.util.List;

public interface StudentService {
    /*分页查询*/
    PageResult<Student> page(StudentQueryParam studentQueryParam);

    /*增加学生*/
    void save(Student student);

    /*根据id查询学生*/
    Student getById(Integer id);

    /*修改学生信息*/
    void updateById(Student student);

    void deleteById(List<Integer> ids);

    void violation(Integer id, Integer score);
}
