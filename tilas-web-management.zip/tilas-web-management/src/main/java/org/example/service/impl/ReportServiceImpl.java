package org.example.service.impl;

import org.example.mapper.ClazzMapper;
import org.example.mapper.EmpMapper;
import org.example.mapper.StudentMapper;
import org.example.pojo.ClazzOption;
import org.example.pojo.JobOption;
import org.example.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ReportServiceImpl implements ReportService {

    @Autowired
    EmpMapper empMapper;

    @Autowired
    StudentMapper studentMapper;

    /*统计员工职位数据*/
    @Override
    public JobOption getEmpJobData() {
        //1. 获取统计数据
        List<Map<String, Object>> list = empMapper.countEmpJobData();
        //查询结果有两列，分别是职位列表以及对应的人数，每一行数据的这两个值封装到一个map的两个key中，多个map组成了这个List

        //2. 封装数据（用流的方法获取每一个map中的两个key再封装为pos和data两个List）
        List<Object> posList = list.stream().map(dataMap -> dataMap.get("pos")).toList();
        List<Object> dataList = list.stream().map(dataMap -> dataMap.get("num")).toList();

        return new JobOption(posList,dataList);
    }

    /*统计员工性别数据*/
    @Override
    public List<Map<String, Object>> getEmpGenderData() {
        return empMapper.countEmpGenderData();
    }

    /*统计班级人数*/
    @Override
    public ClazzOption getClazzCountData() {
        List<Map<String,Object>> list = studentMapper.getClazzCountStudentData();
        List<Object> clazzList = list.stream().map(dataMap -> dataMap.get("clazz")).toList();
        List<Object> countList = list.stream().map(dataMap -> dataMap.get("count")).toList();
        return new ClazzOption(clazzList,countList);
    }

    /*统计学生学历信息*/
    @Override
    public List<Map<String, Object>> getStudentDegreeData() {
        return studentMapper.countDgreeData();
    }
}
