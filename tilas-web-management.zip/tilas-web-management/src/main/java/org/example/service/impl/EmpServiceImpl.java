package org.example.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.example.mapper.EmpExprMapper;
import org.example.mapper.EmpMapper;
import org.example.pojo.*;
import org.example.service.EmpService;
import org.example.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class EmpServiceImpl implements EmpService {

    @Autowired
    private EmpMapper empMapper;
    @Autowired
    private EmpExprMapper empExprMapper;

    /*--------------------------------------原始方法实现分页查询---------------------------------------------------------
    @Override
    public PageResult<Emp> page(Integer page, Integer pageSize) {
        Long total = empMapper.count();  //查询总记录数
        List<Emp> rows = empMapper.list((page-1)*pageSize,pageSize);  //获取分页查询的结果（起始索引=(页码-1)*每页记录数）
        return new PageResult<Emp>(total,rows);
    }
    *---------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------PageHelper插件实现分页查询----------------------------------------------------*/
    public PageResult<Emp> page(EmpQueryParam empQueryParam){
        //1.设置分页参数（页码，每页包含记录数）
        PageHelper.startPage(empQueryParam.getPage(),empQueryParam.getPageSize());
        //2.执行查询
        List<Emp> empList = empMapper.list(empQueryParam);
        //3.定义Page对象，泛型为分页查询的结果对象。通过Page对象调用方法，如.getTotal()获得结果总数，.getResult获取分页查询的结果
        Page<Emp> p=(Page<Emp>) empList;
        return new PageResult<Emp>(p.getTotal(),p.getResult());
    }

    @Transactional //将该方法交给Spring进行事务管理，方法开始前开启事务，所有代码执行成功提交事务；有异常则回滚事务（一般加在service层的方法上）
                   //默认遇到运行时异常RunTimeException才会回滚。若想遇到任何异常都要回滚，添加属性@Transactional(rollbackFor = {Exception.class})
                   /*还有一个属性propagation来控制事务的传播行为，即一个事务方法被另一个事务方法调用时是否创建新的事务。默认值为REQUIRED，意为
                     在执行这个方法时，判断当前是否已经开启了事务了，如果有则合并进一个事务中；置为REQUIRES_NEW意为即使已经开启了事务，对这个方
                     法创建一个新的事务来控制。例子：若想无论是否有异常，都要将数据写入一个数据库中的日志表中，即使将写日志的代码写在try/catch的
                     finally中，也会因为事务遇到异常回滚而不会执行写日志。所以要为写日志的代码单独创建一个事务，即在写日志的方法前加上@Transac
                     tional(propagation=REQUIRES_NEW)。*/
    @Override
    public void save(Emp emp) {
        if (emp.getPhone() == null || emp.getPhone().trim().isEmpty()) {
            emp.setPhone("未提供"); // 或其他默认值
        }
        //1.保存员工基本信息
        emp.setCreateTime(LocalDateTime.now());
        emp.setUpdateTime(LocalDateTime.now());
        empMapper.insert(emp);

        //2.批量保存员工工作经历（一个员工可能有多条工作经历）
        List<EmpExpr> exprList = emp.getExprList();
        if(!CollectionUtils.isEmpty(exprList)){
            //遍历集合，为每一个工作经历添加对应的员工id
            exprList.forEach(empExpr -> {
                empExpr.setEmpId(emp.getId());
            });
            //保存工作经历
            empExprMapper.insertBatch(exprList);
        }
    }

    /*批量删除员工信息*/
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void deleteById(List<Integer> ids) {
        //1.批量删除员工基本信息
        empMapper.deleteById(ids);

        //2.批量删除员工工作经历
        empExprMapper.deleteByEmpId(ids);
    }

    /*根据id查询员工信息*/
    @Override
    public Emp getInfo(Integer id) {
        return empMapper.getById(id);
    }

    /*修改员工信息*/
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void update(Emp emp) {
        //1 修改员工基本信息
        emp.setUpdateTime(LocalDateTime.now());
        empMapper.updateById(emp);

        //2 修改工作经历
        //2.1 删除原有经历
        empExprMapper.deleteByEmpId(Arrays.asList(emp.getId()));
        //2.2 添加新的经历
        List<EmpExpr> exprList = emp.getExprList();
        if(!CollectionUtils.isEmpty(exprList)){
            //遍历集合，为每一个工作经历添加对应的员工id
            exprList.forEach(empExpr -> {
                empExpr.setEmpId(emp.getId());
            });
            //保存工作经历
            empExprMapper.insertBatch(exprList);
        }
    }

    /*查询所有员工信息*/
    @Override
    public List<Emp> list() {
        return empMapper.getAll();
    }

    /*登录*/
    @Override
    public LoginInfo login(Emp emp) {
        Emp e = empMapper.SelectByUsernameAndPassword(emp);
        if(e != null){
            log.info("登录成功{}",emp);
            /*生成JWT令牌*/
            Map<String, Object> claims = new HashMap<>();
            claims.put("id",e.getId());
            claims.put("username",e.getUsername());
            String jwt = JwtUtils.generateToken(claims);

            return new LoginInfo(e.getId(),e.getUsername(),e.getName(),jwt);
        }
        return null;
    }
}
