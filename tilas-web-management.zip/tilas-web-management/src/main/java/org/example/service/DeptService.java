package org.example.service;

import org.example.pojo.Dept;
import org.example.pojo.Result;

import java.util.List;

public interface DeptService {

    /*查询所有部门数据*/
    List<Dept> findAll();

    /*根据id删除部门*/
    void deleteById(Integer id);

    /*添加部门*/
    void add(Dept dept);

    /*根据id查询部门*/
    Dept getById(Integer id);

    /*更改部门信息*/
    void update(Dept dept);
}
