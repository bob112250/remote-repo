package org.example.service;

import org.example.pojo.Clazz;
import org.example.pojo.ClazzQueryParam;
import org.example.pojo.PageResult;
import org.example.pojo.exception.ClazzHasStudentsException;

import java.util.List;

public interface ClazzService {

    /*分页查询*/
    PageResult<Clazz> page(ClazzQueryParam param);


    void deleteById(Integer id) throws ClazzHasStudentsException;

    void save(Clazz clazz);

    Clazz getById(Integer id);

    void update(Clazz clazz);

    List<Clazz> list();
}
