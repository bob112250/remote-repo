package org.example.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.example.mapper.ClazzMapper;
import org.example.mapper.StudentMapper;
import org.example.pojo.Clazz;
import org.example.pojo.ClazzQueryParam;
import org.example.pojo.PageResult;
import org.example.pojo.exception.ClazzHasStudentsException;
import org.example.service.ClazzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class ClazzServiceImpl implements ClazzService {

    @Autowired
    private ClazzMapper clazzMapper;

    @Autowired
    private StudentMapper studentMapper;

    /*分页查询班级*/
    @Override
    public PageResult<Clazz> page(ClazzQueryParam param) {
        param.setNow(LocalDate.now());
        PageHelper.startPage(param.getPage(), param.getPageSize());
        List<Clazz> clazzList = clazzMapper.list(param);
        Page<Clazz> p=(Page<Clazz>) clazzList;
        return new PageResult<Clazz>(p.getTotal(),p.getResult());
    }

    /*根据id删除班级*/
    @Override
    public void deleteById(Integer id) throws ClazzHasStudentsException{
        int studentCount = studentMapper.countByClazzId(id);
        if (studentCount > 0) {
            throw new ClazzHasStudentsException("该班级下还有"+studentCount+"个学生");
        }
        clazzMapper.deleteById(id);
    }


    /*添加班级*/
    @Override
    public void save(Clazz clazz) {
        clazz.setCreateTime(LocalDateTime.now());
        clazz.setUpdateTime(LocalDateTime.now());
        clazzMapper.save(clazz);
    }

    /*根据id查询班级*/
    @Override
    public Clazz getById(Integer id) {
        return clazzMapper.getById(id);
    }

    /*修改班级信息*/
    @Override
    public void update(Clazz clazz) {
        clazz.setUpdateTime(LocalDateTime.now());
        clazzMapper.update(clazz);
    }

    /*查询所有班级信息*/

    @Override
    public List<Clazz> list() {
        LocalDate now = LocalDate.now();
        return clazzMapper.getAllClazz(now);
    }
}
