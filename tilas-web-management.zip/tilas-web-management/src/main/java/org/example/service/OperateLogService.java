package org.example.service;

import org.example.pojo.OperateLog;
import org.example.pojo.PageResult;

public interface OperateLogService {
    /*分页查询操作日志*/
    PageResult<OperateLog> page(Integer page, Integer pageSize);
}
