package org.example.exception;

/*如果让后端自动响应异常，异常类型不是标准响应结果Result，前端无法识别*/
/*全局异常处理器，用于处理遇到的异常，用标准响应结果Result封装返回给前端*/

import lombok.extern.slf4j.Slf4j;
import org.example.pojo.Result;
import org.example.pojo.exception.ClazzHasStudentsException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionalHandler {

    /*接收所有类型的异常*/
    @ExceptionHandler  //该注解用于声明这是一个异常处理方法
    public Result handleException(Exception e){
        log.error("程序出错了！");
        return Result.error("出错啦，请联系管理员");
    }

    /*接收信息重复类异常。遇到异常调用方法时，会按照异常的继承关系从下往上调用方法。*/
    @ExceptionHandler
    public Result handleDuplicateKeyException(DuplicateKeyException e){
        log.error("信息有重复！");
        String message = e.getMessage();  //获取异常信息
        //以下代码根据控制台出现的异常信息，获取哪个信息重复
        int i = message.indexOf("Duplicate entry");
        String errMsg = message.substring(i);
        String[] arr = errMsg.split(" ");
        return Result.error(arr[2]+"已存在");
    }

    @ExceptionHandler
    public Result handleClazzHasStudentsException(ClazzHasStudentsException e) {
        return Result.error("对不起，该班级下还有学生，不能直接删除");
    }
}
