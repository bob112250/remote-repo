package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@ServletComponentScan    //开启Servlet组件支持，用于使用过滤器filter
@SpringBootApplication    //具备组件扫描的功能，因此能够将bean类注入到IOC容器中，默认扫描范围为当前包（即org.example）及其子包

//@ComponentScan(basePackages = {"com.example","org.example"})
//如果想用导入的第三方工具包(假设为com.example)中的类，必须添加注解@ComponentScan，指明扫描范围。
//如果使用了这个注解，那么原来的默认扫描范围就不生效了，需要在扫描范围中添加原来的扫描范围，即org.example

public class ManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ManagementApplication.class, args);
    }

}
