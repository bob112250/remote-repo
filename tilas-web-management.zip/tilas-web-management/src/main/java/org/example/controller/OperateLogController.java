package org.example.controller;

/*
* 操作日志日志的controller
* */

import lombok.extern.slf4j.Slf4j;
import org.example.pojo.OperateLog;
import org.example.pojo.PageResult;
import org.example.pojo.Result;
import org.example.service.OperateLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/log")
public class OperateLogController {

    @Autowired
    private OperateLogService operateLogService;


    /*分页查询日志*/
    @GetMapping("/page")
    public Result page(Integer page, Integer pageSize){
        log.info("分页查询：{}，{}",page,pageSize);
        PageResult<OperateLog> pageResult = operateLogService.page(page,pageSize);
        return Result.success(pageResult);
    }
}
