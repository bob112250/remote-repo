package org.example.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.anno.Log;
import org.example.pojo.Dept;
import org.example.pojo.Result;
import org.example.service.DeptService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RequestMapping("/depts")      //可以给这个类添加路径，这样这个类中的方法的完整路径就是类的路径拼接上方法的路径（类可以没有@RequestMapping注解，但方法必须有）
@RestController
public class DeptController {

    //private static final Logger log = LoggerFactory.getLogger(DeptController.class);  //注意Logger时slf4j包下的接口，不要导错包
    //因为引入了lombok依赖，所以可以省略上面这句话，直接在类上面添加@Slf4j注解即可

    @Autowired
    private DeptService deptService;

    /*获取所有部门数据*/
    //@RequestMapping(value = "/depts",method = RequestMethod.GET)
    //该注解用于将方法与http请求绑定，即当用户发送一个请求到/depts时，会调用list方法。后面的method属性用于限定请求的方式只能是GET。
    //这行注解可以用下面这行注解@GetMapping来代替，这个注解名就已经限定了请求方式为GET
    @GetMapping
    public Result list() {
        log.info("查询全部部门的数据");
        List<Dept> deptList=deptService.findAll();
        return Result.success(deptList);
    }

    /*根据id删除部门（前端传入参数为int类型，名为id）*/
    @Log
    @DeleteMapping
    //public Result deleteById(@RequestParam(value = "id",required = true) Integer deptId) {
    public Result deleteById(Integer id){
        /* 根据@RequestParam("参数名")注解，将请求中的参数id，映射到deptId变量中
           其中的required不写默认为true，意为客户端必须传递该参数，否则报错；若置为false，意为可以不传递参数，deptId值为null
           如果客户端传递过来的参数名与方法形参名相同，那么这个注解可以省略不屑，即把形参名由deptId改为id */
        log.info("根据id删除部门：{}",id);   //{}为占位符，id编译时会替代{}，类似C语言
        deptService.deleteById(id);
        return Result.success();
    }

    //添加部门（前端传入参数为json字串，名为name）
    @Log
    @PostMapping
    public Result addDept(@RequestBody Dept dept){
        //@RequestBody注解用于将json字串封装到一个类中，前提是类中有属性与jason串中的key同名,传入的参数就赋值给这个类中的这个属性，这个类的其他属性置为null
        log.info("新增部门：{}",dept);
        deptService.add(dept);
        return Result.success();
    }

    //根据id查询部门（前端传入参数为路径参数，如localhost:8080/depts/3，id值为3）
    @GetMapping("{id}")
    public Result getDept(@PathVariable Integer id){   //@PathVariable注解用于将路径参数赋值给id，注意这个形参名应该与占位符{}内的名相同
        log.info("根据id查询部门：{}",id);
        Dept dept=deptService.getById(id);
        return Result.success(dept);
    }

    //修改部门信息（前端传入参数为json字串，有id和name两个key
    @Log
    @PutMapping
    public Result update(@RequestBody Dept dept){
        log.info("修改部门：{}",dept);
        deptService.update(dept);
        return Result.success();
    }
}

