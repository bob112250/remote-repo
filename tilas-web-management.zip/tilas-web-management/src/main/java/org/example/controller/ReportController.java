package org.example.controller;

/*
* 图形报表统计controller
*/

import lombok.extern.slf4j.Slf4j;
import org.example.pojo.ClazzOption;
import org.example.pojo.JobOption;
import org.example.pojo.Result;
import org.example.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/report")
public class ReportController {

    @Autowired
    ReportService reportService;

    /*统计员工职位数据*/
    @GetMapping("/empJobData")
    public Result getEmpJobData(){
        JobOption jobOption = reportService.getEmpJobData();
        return Result.success(jobOption);
    }

    /*统计员工性别数据*/
    @GetMapping("/empGenderData")
    public Result getEmpGenderData(){
        List<Map<String,Object>> list = reportService.getEmpGenderData();
        return Result.success(list);
    }

    /*统计班级人数*/
    @GetMapping("/studentCountData")
    public Result getClazzCountData(){
        ClazzOption clazzOption = reportService.getClazzCountData();
        return Result.success(clazzOption);
    }

    /*统计学生学历*/
    @GetMapping("/studentDegreeData")
    public Result getStudentDegreeData(){
        List<Map<String,Object>> list = reportService.getStudentDegreeData();
        return Result.success(list);
    }
}
