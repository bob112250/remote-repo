package org.example.controller;
import lombok.extern.slf4j.Slf4j;
import org.example.pojo.Result;
import org.example.utils.AliyunOSSOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/*本地磁盘存储方案*/
/*@Slf4j
@RestController
public class UploadController {
    @PostMapping("/upload")
    public Result upload(String name, Integer age, MultipartFile file) throws IOException {   //形参中必须有MultipartFile来接受上传上来的文件
        log.info("接受参数：{},{},{}",name,age,file);

        //获取原始的文件名
        String originalFilename = file.getOriginalFilename();
        //为了避免上传两个文件的文件名相同而导致保存在本地目录的文件夹时第二个文件覆盖了第一个文件，需要给这个文件起一个新的名字
        String extension = originalFilename.substring(originalFilename.lastIndexOf('.'));  //获取原来文件的后缀名，新名的后缀需保持一致
        String newFileName = UUID.randomUUID().toString() + extension;
        //将该文件保存到本地磁盘目录
        file.transferTo(new File("E:/images/" + newFileName));
        return Result.success();
    }
}*/

/*将文件上传到阿里云OSS云端存储方案*/
@Slf4j
@RestController
public class UploadController{

    @Autowired
    private AliyunOSSOperator aliyunOSSOperator;  //要使用OSS工具类，先要注入

    @PostMapping("/upload")
    public Result upload(MultipartFile file) throws Exception {
        log.info("文件上传：{}",file.getOriginalFilename());
        String url = aliyunOSSOperator.upload(file.getBytes(), file.getOriginalFilename());  //返回值为该文件上传到云端后的url地址
        return Result.success(url);
    }
}
