package org.example.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.anno.Log;
import org.example.pojo.Clazz;
import org.example.pojo.ClazzQueryParam;
import org.example.pojo.PageResult;
import org.example.pojo.Result;
import org.example.pojo.exception.ClazzHasStudentsException;
import org.example.service.ClazzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Slf4j
@RestController
@RequestMapping("/clazzs")
public class ClazzController {

    @Autowired
    private ClazzService clazzService;

    /*分页查询所有班级信息*/
    @GetMapping
    public Result getAllClazz(ClazzQueryParam param){
        log.info("分页查询：{}",param);
        PageResult<Clazz> pageResult = clazzService.page(param);
        return Result.success(pageResult);
    }

    /*根据id删除班级*/
    @Log
    @DeleteMapping("/{id}")
    public Result deleteById(@PathVariable Integer id) throws ClazzHasStudentsException {
        log.info("删除班级：{}",id);
        clazzService.deleteById(id);
        return Result.success();
    }

    /*添加班级*/
    @Log
    @PostMapping
    public Result save(@RequestBody Clazz clazz){
        log.info("添加班级：{}", clazz);
        clazzService.save(clazz);
        return Result.success();
    }

    /*根据id查询班级*/
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        log.info("查询班级：{}",id);
        Clazz clazz = clazzService.getById(id);
        return Result.success(clazz);
    }

    /*修改班级信息*/
    @Log
    @PutMapping
    public Result update(@RequestBody Clazz clazz){
        log.info("修改班级：{}", clazz);
        clazzService.update(clazz);
        return Result.success();
    }

    /*查询所有班级信息，用于增加学生时选择班级*/
    @GetMapping("/list")
    public Result list(){
        log.info("查询所有班级");
        List<Clazz> clazzList = clazzService.list();
        return Result.success(clazzList);
    }
}
