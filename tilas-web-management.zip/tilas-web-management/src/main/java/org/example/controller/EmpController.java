package org.example.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.anno.Log;
import org.example.pojo.Emp;
import org.example.pojo.EmpQueryParam;
import org.example.pojo.PageResult;
import org.example.pojo.Result;
import org.example.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/emps")
public class EmpController {

    @Autowired
    private EmpService empService;

    /*根据条件（姓名，性别，入职时间范围）分页查询*//*
    @GetMapping
    public Result page(@RequestParam(defaultValue = "1") Integer page,
                       @RequestParam(defaultValue = "10") Integer pageSize,
                       String name, Integer gender,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end){
                        //@RequestParam注解也可以为参数设置默认值，注意值要用双引号包裹
                        //因为前端传过来的时间有可能为不同的样式，为了统一样式便于封装，使用@DateTimeFormat注解来指定时间的样式
        log.info("分页查询：{},{},{},{},{},{}",page,pageSize,name,gender,begin,end);
        PageResult<Emp> pageResult = empService.page(page,pageSize,name,gender,begin,end);   //service层将分页查询结果封装为PageResult后返回
        return Result.success(pageResult);  //将PageResult对象封装为标准的返回结果对象Result后响应给前端*/

    /*优化：对于？后面参数过多的情况，可以将所有参数封装在一个类中，用这个类的对象代表所有参数*/
    @GetMapping
    public Result page(EmpQueryParam empQueryParam) {
        log.info("分页查询：{}", empQueryParam);
        PageResult<Emp> pageResult = empService.page(empQueryParam);
        return Result.success(pageResult);
    }

    /*新增员工*/
    @Log
    @PostMapping
    public Result save(@RequestBody Emp emp) throws Exception {
        log.info("添加员工：{}", emp);
        empService.save(emp);
        return Result.success();
    }

    /*根据id批量删除员工（删除一个员工属于批量删除的一种情况）*/  //传参样例：/emps?ids=1,2,3
    //方式一：用数组接收参数
//    @DeleteMapping
//    public Result delete(Integer[] ids){
//        log.info("根据id批量删除员工：{}",ids);
//        return Result.success();
//    }
//
    //方式二：用list集合接收参数
    @Log
    @DeleteMapping
    public Result delete(@RequestParam List<Integer> ids) {   //想用List这样比较复杂的容器来接收参数，必须添加注解@RequestParam
        log.info("根据id批量删除员工：{}", ids);
        empService.deleteById(ids);
        return Result.success();
    }


    /*根据id查询员工信息（包括基本信息和工作经历）*/
    @GetMapping("/{id}")
    public Result getInfo(@PathVariable Integer id){  //对于路径参数，必须用@PathVariable注解
        log.info("根据id查询员工：{}",id);
        Emp emp = empService.getInfo(id);
        return Result.success(emp);
    }

    /*修改员工信息（传参为一个Jason字符串）*/
    @Log
    @PutMapping
    public Result update(@RequestBody Emp emp){    //传参为Jason字符串时要用@RequestBody注解
        empService.update(emp);
        return Result.success();
    }

    /*查询所有员工*/
    @GetMapping("/list")
    public Result list(){
        log.info("查询所有员工");
        List<Emp> list = empService.list();
        return Result.success(list);
    }
}