package org.example.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.anno.Log;
import org.example.pojo.PageResult;
import org.example.pojo.Result;
import org.example.pojo.Student;
import org.example.pojo.StudentQueryParam;
import org.example.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    /*根据条件分页查询学生*/
    @GetMapping
    public Result page(StudentQueryParam studentQueryParam){
        log.info("分页查询：{}",studentQueryParam);
        PageResult<Student> pageResult = studentService.page(studentQueryParam);
        return Result.success(pageResult);
    }

    /*添加学生*/
    @Log
    @PostMapping
    public Result save(@RequestBody Student student){
        log.info("添加学生：{}", student);
        studentService.save(student);
        return Result.success();
    }

    /*根据id查询学生*/
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        log.info("查询学生：{}",id);
        Student student = studentService.getById(id);
        return Result.success(student);
    }

    /*修改学生信息*/
    @Log
    @PutMapping
    public Result update(@RequestBody Student student){
        log.info("修改学生：{}", student);
        studentService.updateById(student);
        return Result.success();
    }

    /*批量删除学员信息*/
    @Log
    @DeleteMapping("/{ids}")
    public Result delete(@PathVariable List<Integer> ids){
        log.info("批量删除：{}", ids);
        studentService.deleteById(ids);
        return Result.success();
    }

    /*违纪处理*/
    @PutMapping("/violation/{id}/{score}")
    public Result violation(@PathVariable Integer id, @PathVariable Integer score){
        log.info("违纪处理：{},{}", id, score);
        studentService.violation(id, score);
        return Result.success();
    }
}
