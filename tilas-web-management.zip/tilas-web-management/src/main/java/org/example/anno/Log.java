package org.example.anno;


/*
* 自定义注解，用于日志记录。想要记录日志，只需要在方法上添加@Log注解即可
* */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)    //表示该注解只能用于方法
@Retention(RetentionPolicy.RUNTIME)    //表示该注解在运行时保留
public @interface Log {
}
