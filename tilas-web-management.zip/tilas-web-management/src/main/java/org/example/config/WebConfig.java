package org.example.config;

/*
* 配置类
* */


import org.example.interceptor.TokenInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

/*
@Configuration    //声明这是一个配置类
public class WebConfig {

    @Autowired
    private TokenInterceptor tokenInterceptor;

    */
/*注册拦截器*//*

    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(tokenInterceptor)
                .addPathPatterns("/**")   //拦截指定路径范围的请求，这里是拦截所有请求（/*匹配的是任意一级路径，如/emp，不能多级路径，如/emp/1；而/**匹配的是任意级路径）
                .excludePathPatterns("/login");   //排除/login的请求，即登录接口不拦截
    }
}
*/
