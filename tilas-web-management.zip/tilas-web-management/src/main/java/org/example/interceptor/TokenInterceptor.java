package org.example.interceptor;

/*
* 令牌校验的拦截器，注意要事先在配置类config中注册拦截器！！！
* 配置类中会指定需要拦截的路径范围，拦截器会自动生效，无需手动调用
* */


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.example.utils.JwtUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
//@Component  //将拦截器交给spring的IOC容器管理
public class TokenInterceptor implements HandlerInterceptor {

    /*在目标资源方法（controller）运行之前运行，返回值为true则放行，为false不放行*/
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        /*1.获取请求路径，如果路径中有/login，说明是登录请求，直接放行
        String requestURI = request.getRequestURI();  //获取的是uri地址
        if(requestURI.contains("/login")){
            log.info("登录请求，放行");
            return true;  //放行
        }*/         //这里注释掉是因为在配置类里面拦截的请求中，已经排除了登录的请求，所以这里不用再判断

        //2.获取请求头中的token
        String token = request.getHeader("token");

        //3.若token为null，说明没登陆，返回错误信息
        if(token == null || token.isEmpty()){
            log.info("令牌为空，响应401");
            response.setStatus(401);  //设置响应状态码为401，未授权
            return false;
        }

        //4.校验token是否有效，无效则返回错误信息
        try{
            JwtUtils.parseToken(token);
        }catch (Exception e){   //令牌解析失败时会抛出异常，说明令牌无效
            log.info("令牌无效，响应401");
            response.setStatus(401);
            return false;
        }

        //5.放行
        return true;
    }

    /*在目标资源方法（controller）运行之后运行*/
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }

    /*在目标资源方法（controller）运行之后，视图渲染之前运行*/
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }
}
