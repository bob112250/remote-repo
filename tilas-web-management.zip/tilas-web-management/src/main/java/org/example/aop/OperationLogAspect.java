package org.example.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.example.mapper.OperateLogMapper;
import org.example.pojo.OperateLog;
import org.example.utils.CurrentHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;

/*
AOP：即面向切面的编程思想，特点是在不改变原代码的基础下，为方法增添新的功能。
具体实现是通过@Aspect注解声明切面类，然后在切面类中定义切点（即哪些方法需要增强）@Pointcut 和 通知（即添加新的功能），包括@Before、@After、@Around。
*/



@Aspect     //表示当前类是一个AOP的切面类
@Component
public class OperationLogAspect {

    @Autowired
    private OperateLogMapper operateLogMapper;

    @Around("@annotation(org.example.anno.Log)")
    public Object recordLog(ProceedingJoinPoint joinPoint) throws Throwable {
        /*joinPoint代表目标方法*/

        long startTime = System.currentTimeMillis();   //记录开始时间

        Object result = joinPoint.proceed();    //运行目标方法

        //计算耗时
        long costTime = System.currentTimeMillis() - startTime;
        OperateLog operateLog = new OperateLog();
        operateLog.setOperateEmpId(getCurrentUserId());
        operateLog.setOperateTime(LocalDateTime.now());
        operateLog.setClassName(joinPoint.getTarget().getClass().getName());   //通过joinPoint对象获取对象名
        operateLog.setMethodName(joinPoint.getSignature().getName());
        operateLog.setMethodParams(Arrays.toString(joinPoint.getArgs()));
        operateLog.setReturnValue(result == null ? "void" : result.toString());
        operateLog.setCostTime(costTime);

        //保存日志
        operateLogMapper.insert(operateLog);

        return result;
    }

    private Integer getCurrentUserId() {
        /*从当前线程中获取当前登录的员工的id*/
        return CurrentHolder.getCurrentId();
    }

}
