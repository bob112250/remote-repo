package org.example.utils;

/*每一次请求都会创建一个线程*/
/*该类用来保存当前登录用户的id，其中的ThreadLocal代表一个线程局部变量，为每一个线程提供一份存储空间，用于同一个线程（同一个请求）中的数据共享*/
/*在TokenFilter过滤器中，解析令牌并获取用户id，并将id传给线程，再通过线程传递给AOP保存日志*/

public class CurrentHolder {

    private static final ThreadLocal<Integer> CURRENT_LOCAL = new ThreadLocal<>();

    public static void setCurrentId(Integer employeeId) {
        CURRENT_LOCAL.set(employeeId);
    }

    public static Integer getCurrentId() {
        return CURRENT_LOCAL.get();
    }

    public static void remove() {
        CURRENT_LOCAL.remove();
    }
}
