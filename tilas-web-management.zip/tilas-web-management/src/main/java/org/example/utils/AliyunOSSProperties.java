package org.example.utils;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component     //声明这是一个bean类
@ConfigurationProperties(prefix = "aliyun.oss")  //声明是在配置项是在哪个路径下
public class AliyunOSSProperties {
    private String endpoint;
    private String bucketName;
    private String region;
}
