package org.example.mapper;

import org.apache.ibatis.annotations.*;
import org.example.pojo.Emp;
import org.example.pojo.EmpExpr;
import org.example.pojo.EmpQueryParam;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface EmpMapper {
    /*--------------------------------------原始方法实现分页查询---------------------------------------------------------
    //查询总记录数
    @Select("select count(*) from emp e left join dept d on e.dept_id=d.id")
    public Long count();

    //分页查询
    @Select("select e.*,d.name deptName from emp e left join dept d on e.dept_id = d.id " +
            "order by e.update_time desc limit #{start},#{pageSize}")
        //关于这条SQL的两个细节：1.对于limit分页查询，页面起始索引start和每页展示的记录数pageSize是前端交给后端的数据，所以用占位符来表示
        //2.查询结果封装为员工类Emp组成的集合，并且要求显示出每名员工的部门名称，所以用左外连接的方式查询，并且要给部门名称d.name起一个别名deptName，用于对应Emp中的deptName属性
    public List<Emp> list(Integer start, Integer pageSize);
    /*---------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------PageHelper插件实现分页查询----------------------------------------------------*/
    //@Select("select e.*,d.name deptName from emp e left join dept d on e.dept_id=d.id order by e.update_time desc") //实现简单的查询即可  //这是进行简单分页查询的步骤，条件分页查询语句封装在xml文件中
    public List<Emp> list(EmpQueryParam empQueryParam);   //xml映射文件放在resources目录下

    /*添加员工*/
    @Options(useGeneratedKeys = true,keyProperty = "id")
    //这个注解的作用是将执行插入操作时mysql赋予这个元素的主键返回，即执行插入语句后，赋予的这个主键值已经赋值给了emp的id属性，这样用emp.getId才能搞获得这个员工的主键值
    @Insert("insert into emp (username, name, gender, phone, job, salary, image, entry_date, dept_id, create_time, update_time) " +
            "VALUES (#{username},#{name},#{gender},#{phone},#{job},#{salary},#{image},#{entryDate},#{deptId},#{createTime},#{updateTime})")
    void insert(Emp emp);


    /*批量删除员工基本信息*/
    void deleteById(List<Integer> ids);

    /*根据id获取员工信息*/
    Emp getById(Integer id);

    /*根据id修改员工信息*/
    void updateById(Emp emp);

    /*统计员工职位人数*/
    @MapKey("pos")
    List<Map<String,Object>> countEmpJobData();

    /*统计员工性别人数*/
    @MapKey("name")
    List<Map<String, Object>> countEmpGenderData();

    /*获取所有员工信息*/
    List<Emp> getAll();

    /*登录*/
    @Select("select e.id,e.name,e.username from emp e where username=#{username} and password=#{password}")
    Emp SelectByUsernameAndPassword(Emp emp);
}
