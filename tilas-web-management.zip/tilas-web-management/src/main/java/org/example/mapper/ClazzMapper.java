package org.example.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.pojo.Clazz;
import org.example.pojo.ClazzQueryParam;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface ClazzMapper {
    List<Clazz> list(ClazzQueryParam param);

    void deleteById(Integer id);

    @Insert("insert into clazz (name , room , begin_date , end_date , master_id , subject, create_time , update_time) " +
            "values (#{name}, #{room},#{beginDate},#{endDate},#{masterId},#{subject},#{createTime},#{updateTime})")
    void save(Clazz clazz);

    @Select("select * from clazz where id=#{id}")
    Clazz getById(Integer id);

    @Update("update clazz set name=#{name}, room=#{room}, begin_date=#{beginDate}, end_date=#{endDate}, master_id=#{masterId}, subject=#{subject}, update_time=#{updateTime} where id=#{id}")
    void update(Clazz clazz);

    @Select("select * from clazz where end_date >= #{now}")
    List<Clazz> getAllClazz(LocalDate now);
}
