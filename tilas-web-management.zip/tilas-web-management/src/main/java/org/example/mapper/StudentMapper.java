package org.example.mapper;

import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.pojo.Student;
import org.example.pojo.StudentQueryParam;

import java.util.List;
import java.util.Map;

@Mapper
public interface StudentMapper {
    /*统计班级人数*/
    List<Map<String, Object>> getClazzCountStudentData();


    @Select("select count(*) from student where clazz_id = #{clazzId}")
    int countByClazzId(Integer clazzId);

    /*分页查询*/
    List<Student> list(StudentQueryParam studentQueryParam);

    /*添加学生*/
    void insert(Student student);

    /*根据id查询学生信息*/
    @Select("select * from student where id = #{id}")
    Student getById(Integer id);

    /*根据id修改学生信息*/
    void updateById(Student student);

    /*批量删除学生信息*/
    void deleteById(List<Integer> ids);

    /*违纪处理*/
    @Update("update student set violation_count = violation_count + 1 ,violation_score = violation_score + #{score} where id = #{id}")
    void setViolation(Integer id, Integer score);

    @MapKey("name")
    List<Map<String, Object>> countDgreeData();
}
