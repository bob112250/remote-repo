package org.example.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.pojo.Emp;
import org.example.pojo.EmpExpr;

import java.util.List;

@Mapper
public interface EmpExprMapper {

    /*批量添加员工的工作经历*/
    void insertBatch(List<EmpExpr> exprList);

    /*批量删除员工工作经历*/
    void deleteByEmpId(List<Integer> empIds);

}